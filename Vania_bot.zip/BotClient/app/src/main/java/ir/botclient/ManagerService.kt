package ir.botclient

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import com.chaquo.python.Python

class ManagerService : BaseService(1, "Highrise Bot Manager") {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var cm: ConnectivityManager

    private val tick = object : Runnable {
        override fun run() { SlotLauncher.ensureAll(this@ManagerService); main.postDelayed(this, 30_000) }
    }
    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { SlotLauncher.ensureAll(this@ManagerService) }
    }

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.registerNetworkCallback(
            NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), cb)
        main.postDelayed(tick, 30_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Diag.log(this, "سرویس مدیر شروع شد")
        if (worker?.isAlive != true) {
            val token = intent?.getStringExtra("t") ?: Prefs.get(this, "mtoken")
            val room = intent?.getStringExtra("r") ?: Prefs.get(this, "mroom")
            val owner = intent?.getStringExtra("o") ?: Prefs.get(this, "mowner")
            if (token.isBlank() || room.isBlank() || owner.isBlank()) {
                Diag.log(this, "❌ خطا: توکن/روم/یوزرنیم خالیه، سرویس متوقف شد")
                stopSelf(); return START_NOT_STICKY
            }
            try {
                Paths.installAssets(this)
                Diag.log(this, "فایل‌های ربات آماده شد، پایتون در حال اجراست...")
            } catch (e: Throwable) {
                Diag.log(this, "❌ خطا در آماده‌سازی فایل‌ها: $e")
                return START_STICKY
            }
            val dir = Paths.botDir(this).absolutePath
            val svc = this
            worker = Thread({
                try {
                    Python.getInstance().getModule("glue").callAttr("run_manager", dir, token, room, owner.trim(), svc)
                } catch (e: Throwable) {
                    android.util.Log.e("BotClient", "manager crashed", e)
                    Diag.log(svc, "❌ خطای پایتون: $e")
                }
            }, "manager-py").also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(tick)
        try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {}
        super.onDestroy()
    }
}
