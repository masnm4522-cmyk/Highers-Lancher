package ir.botclient

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Diag {
    fun log(ctx: Context, msg: String) {
        try {
            val d = Paths.botDir(ctx).apply { mkdirs() }
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            File(d, "manager.log").appendText("$ts [APP] $msg\n")
        } catch (_: Exception) {}
    }
}
