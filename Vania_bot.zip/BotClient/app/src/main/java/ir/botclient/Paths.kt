package ir.botclient

import android.content.Context
import java.io.File

object Paths {
    fun botDir(c: Context) = File(c.filesDir, "bot")

    /** Copies the bundled bot code (assets/bot) into the writable bot folder. User data is never in assets, so it is never touched. */
    fun installAssets(c: Context) {
        val dst = botDir(c).apply { mkdirs() }
        for (name in c.assets.list("bot") ?: emptyArray()) {
            c.assets.open("bot/$name").use { i -> File(dst, name).outputStream().use { o -> i.copyTo(o) } }
        }
    }
}
