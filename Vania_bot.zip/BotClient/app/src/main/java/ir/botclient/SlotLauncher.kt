package ir.botclient

import android.content.Context
import android.content.Intent
import java.io.File

object SlotLauncher {
    const val COUNT = 6
    private val classes = arrayOf<Class<*>>(
        Slot0::class.java, Slot1::class.java, Slot2::class.java,
        Slot3::class.java, Slot4::class.java, Slot5::class.java
    )

    @JvmStatic fun start(ctx: Context, slot: Int) {
        ctx.startForegroundService(Intent(ctx, classes[slot]))
    }

    @JvmStatic fun stop(ctx: Context, slot: Int) {
        ctx.stopService(Intent(ctx, classes[slot]))
    }

    /** Restart slot services whose assignment file still exists (e.g. after the system killed them). */
    @JvmStatic fun ensureAll(ctx: Context) {
        for (i in 0 until COUNT) {
            if (File(Paths.botDir(ctx), "slots/slot$i.json").exists()) {
                try { start(ctx, i) } catch (_: Exception) {}
            }
        }
    }

    fun stopAll(ctx: Context) { for (i in 0 until COUNT) stop(ctx, i) }
}
