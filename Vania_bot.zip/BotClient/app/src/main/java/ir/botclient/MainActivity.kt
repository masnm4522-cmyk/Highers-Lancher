package ir.botclient

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import org.json.JSONObject
import org.json.JSONArray
import java.io.RandomAccessFile
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private val GOLD = Color.parseColor("#FF2E93")
    private val GOLD_DARK = Color.parseColor("#B0125F")
    private val GOLD_SOFT = Color.parseColor("#FFD1E8")
    private val GRAY = Color.parseColor("#8A8A8A")
    private val GREEN = Color.parseColor("#4ADE80")
    private val RED = Color.parseColor("#EF4444")

    private lateinit var pill: TextView
    private lateinit var mainBtn: TextView
    private lateinit var batteryLink: TextView
    private lateinit var logView: TextView
    private lateinit var fToken: EditText
    private lateinit var fRoom: EditText
    private lateinit var fOwner: EditText
    private var tokenShown = false
    private lateinit var outfitBox: LinearLayout
    private lateinit var fleetBox: LinearLayout
    private lateinit var outfitFilter: EditText
    private lateinit var commandSearch: EditText
    private lateinit var commandList: LinearLayout
    private var outfitStamp = -1L
    private var fleetStamp = -1L
    private var outfitFilterValue = ""
    private var commandExpanded = false
    private val ui = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1500) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int = 0, radius: Int = 14, strokeDp: Int = 1) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(strokeDp), stroke)
        }

    private fun grad(c1: Int, c2: Int, radius: Int = 16) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(radius).toFloat()
        }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(GOLD); gravity = Gravity.START
        setPadding(dp(4), dp(10), dp(4), dp(4))
    }

    private fun input(hint: String, key: String) = EditText(this).apply {
        this.hint = hint; setText(Prefs.get(this@MainActivity, key)); setSingleLine()
        setTextColor(GOLD_SOFT); setHintTextColor(Color.parseColor("#6B6B6B")); textSize = 14f
        background = box(Color.parseColor("#1A1A1A"), Color.parseColor("#5A1A3A"), 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        textDirection = View.TEXT_DIRECTION_LTR
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(28), dp(20), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#050505"), Color.parseColor("#1A0510"), Color.parseColor("#000000"))
            )
        }

        // logo
        root.addView(TextView(this).apply {
            text = "V"; textSize = 34f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(GOLD, GOLD_DARK)).apply { cornerRadius = dp(20).toFloat() }
        }, LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        root.addView(TextView(this).apply {
            text = getString(R.string.app_title); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(GOLD); letterSpacing = 0.15f; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(2))
        })
        root.addView(TextView(this).apply {
            text = "لانچر ربات هایرایز 🎀"; textSize = 13f; setTextColor(GRAY); gravity = Gravity.CENTER
        })

        pill = TextView(this).apply {
            textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        root.addView(pill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14); bottomMargin = dp(14) })

        // card
        fRoom = input("آیدی روم", "mroom")
        fToken = input("توکن ربات", "mtoken").apply { transformationMethod = PasswordTransformationMethod.getInstance() }
        fOwner = input("یوزرنیم شما در هایرایز", "mowner")
        val showToken = TextView(this).apply {
            text = "👁 نمایش توکن"; textSize = 12f; setTextColor(GOLD_DARK); gravity = Gravity.START
            setPadding(dp(4), dp(6), dp(4), 0)
            setOnClickListener {
                tokenShown = !tokenShown
                fToken.transformationMethod = if (tokenShown) null else PasswordTransformationMethod.getInstance()
            }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#C2185B"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(18))
        }
        card.addView(label("بات اصلی"))
        card.addView(label("آیدی روم (Room ID)  🏠")); card.addView(fRoom)
        card.addView(label("توکن ربات  🔑")); card.addView(fToken); card.addView(showToken)
        card.addView(label("یوزرنیم شما در هایرایز (مالک)  👑")); card.addView(fOwner)
        root.addView(card)

        // start / stop
        mainBtn = TextView(this).apply {
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(0, dp(15), 0, dp(15))
            setOnClickListener { onMainButton() }
        }
        root.addView(mainBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val fleetCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#C2185B"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(14))
        }
        fleetCard.addView(label("مدیریت بات‌های اضافی  🤖"))
        fleetCard.addView(TextView(this).apply {
            text = "پروفایل‌ها سقف ثابتی ندارند؛ تعداد بات‌های روشن به توان گوشی و محدودیت سرویس بستگی دارد."
            textSize = 11f; setTextColor(GRAY); setPadding(dp(4), 0, dp(4), dp(8))
        })
        fleetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fleetCard.addView(fleetBox)
        fleetCard.addView(TextView(this).apply {
            text = "نمایش لاگ بات‌های اضافی"; textSize = 11f; setTextColor(GOLD)
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4))
            setOnClickListener { showFleetLog() }
        })
        fleetCard.addView(TextView(this).apply {
            text = "＋ افزودن بات"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK); gravity = Gravity.CENTER
            background = grad(GOLD, GOLD_DARK, 12)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { openProfileEditor(null) }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        fleetCard.addView(TextView(this).apply {
            text = "⏹ توقف همه‌ی بات‌های اضافی"; textSize = 12f; setTextColor(RED)
            gravity = Gravity.CENTER
            background = box(Color.TRANSPARENT, RED, 12)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { stopAllProfiles() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(fleetCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        batteryLink = TextView(this).apply {
            textSize = 12f; setTextColor(GOLD); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
        root.addView(batteryLink)

        // ست‌های لباس (کپی‌شده از توی بازی با !copy @user)
        val outfitCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#C2185B"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(14))
        }
        outfitCard.addView(label("ست‌های لباس  👗"))
        outfitFilter = input("جست‌وجو بین ست‌های ذخیره‌شده", "outfit_search").apply {
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    outfitStamp = -1L
                    refreshOutfits()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        outfitCard.addView(outfitFilter)
        outfitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outfitCard.addView(outfitBox)
        root.addView(outfitCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        // فهرست قابل جست‌وجوی همه‌ی فرمان‌های فعلی؛ متن از راهنمای خود بات خوانده می‌شود.
        val commandCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#315A9A"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(14))
        }
        commandCard.addView(label("فرمان‌های بات  📖"))
        val commandToggle = TextView(this).apply {
            text = "نمایش فهرست فرمان‌ها  ▾"
            textSize = 14f
            setTextColor(GOLD_SOFT)
            gravity = Gravity.CENTER
            background = box(Color.parseColor("#171717"), Color.parseColor("#315A9A"), 12)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        commandCard.addView(commandToggle)
        commandSearch = input("جست‌وجوی دستور یا توضیح", "command_search").apply {
            visibility = View.GONE
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (commandExpanded) renderCommandCatalog(s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        commandCard.addView(commandSearch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        commandList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        commandCard.addView(commandList)
        commandToggle.setOnClickListener {
            commandExpanded = !commandExpanded
            commandSearch.visibility = if (commandExpanded) View.VISIBLE else View.GONE
            commandList.visibility = if (commandExpanded) View.VISIBLE else View.GONE
            commandToggle.text = if (commandExpanded) "بستن فهرست فرمان‌ها  ▴" else "نمایش فهرست فرمان‌ها  ▾"
            if (commandExpanded) renderCommandCatalog(commandSearch.text.toString())
        }
        root.addView(commandCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        // log panel
        val logCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0A0A0A"), Color.parseColor("#5A1A3A"), 16)
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        logCard.addView(TextView(this).apply {
            text = "LOG  ●●●"; textSize = 11f; setTextColor(GOLD); gravity = Gravity.END
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        })
        logView = TextView(this).apply {
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(GOLD_SOFT)
            layoutDirection = View.LAYOUT_DIRECTION_LTR; textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true); setPadding(0, dp(8), 0, 0)
        }
        logCard.addView(logView)
        root.addView(logCard)

        fun outline(t: String, color: Int, action: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(color); gravity = Gravity.CENTER
            background = box(Color.TRANSPARENT, color, 14)
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { action() }
        }
        root.addView(outline("📋 کپی لاگ", GOLD) { copyLog() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(outline("🗑 پاک کردن همه بات‌ها و اطلاعات", RED) { confirmWipe() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); isFillViewport = true; addView(root) })
    }

    override fun onResume() { super.onResume(); ui.post(poll) }
    override fun onPause() { ui.removeCallbacks(poll); super.onPause() }

    private fun onMainButton() {
        if (Prefs.wantRunning(this)) {
            stopMainBot()
        } else {
            val t = fToken.text.toString().trim(); val r = fRoom.text.toString().trim(); val o = fOwner.text.toString().trim()
            if (t.isEmpty() || r.isEmpty() || o.isEmpty()) {
                Toast.makeText(this, "همه فیلدها رو پر کن", Toast.LENGTH_SHORT).show(); return
            }
            Prefs.set(this, "mtoken", t); Prefs.set(this, "mroom", r); Prefs.set(this, "mowner", o)
            File(Paths.botDir(this), "manager.log").delete()
            Prefs.setWantRunning(this, true)
            ensurePermissions()
            startForegroundService(Intent(this, ManagerService::class.java)
                .putExtra("t", t).putExtra("r", r).putExtra("o", o))
        }
        refresh()
    }

    private fun profilesFile() =
        File(Paths.botDir(this).apply { mkdirs() }, "launcher_bots.json")

    private fun readProfiles(): ArrayList<JSONObject> {
        val out = ArrayList<JSONObject>()
        try {
            val array = JSONArray(profilesFile().readText())
            for (i in 0 until array.length()) {
                val profile = array.optJSONObject(i) ?: continue
                if (profile.optString("id").isNotBlank()) out.add(profile)
            }
        } catch (_: Exception) {}
        return out
    }

    private fun writeProfiles(profiles: List<JSONObject>) {
        val file = profilesFile()
        val temp = File(file.parentFile, file.name + ".tmp")
        val array = JSONArray()
        profiles.forEach { array.put(it) }
        temp.writeText(array.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(temp.readText(), Charsets.UTF_8)
            temp.delete()
        }
    }

    private fun saveProfilesAndSync(profiles: List<JSONObject>) {
        writeProfiles(profiles)
        val shouldRun = profiles.any { it.optBoolean("enabled", false) }
        Prefs.setWantFleet(this, shouldRun)
        if (shouldRun) {
            ensurePermissions()
            try {
                startForegroundService(Intent(this, FleetService::class.java))
            } catch (e: Exception) {
                Toast.makeText(this, "سرویس بات‌ها اجرا نشد: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        } else {
            stopService(Intent(this, FleetService::class.java))
        }
        fleetStamp = -1L
        refreshFleet()
    }

    private fun openProfileEditor(existing: JSONObject?) {
        fun field(hint: String, value: String = "", secret: Boolean = false) = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine()
            setTextColor(GOLD_SOFT)
            setHintTextColor(Color.parseColor("#6B6B6B"))
            textSize = 14f
            background = box(Color.parseColor("#1A1A1A"), Color.parseColor("#5A1A3A"), 12)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            textDirection = View.TEXT_DIRECTION_LTR
            if (secret) transformationMethod = PasswordTransformationMethod.getInstance()
        }

        val nameField = field("نام برای شناسایی بات", existing?.optString("name", "").orEmpty())
        val tokenField = field(
            if (existing == null) "توکن بات" else "توکن جدید (خالی = بدون تغییر)",
            secret = true
        )
        val roomField = field("آیدی روم", existing?.optString("room", "").orEmpty())
        val ownerField = field("یوزرنیم مالک", existing?.optString("owner", "").orEmpty())
        var role = existing?.optString("role", "normal") ?: "normal"
        val roleButton = TextView(this).apply {
            textSize = 13f; setTextColor(GOLD_SOFT); gravity = Gravity.CENTER
            background = box(Color.parseColor("#1A1A1A"), Color.parseColor("#5A1A3A"), 12)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                    .setTitle("نوع بات")
                    .setSingleChoiceItems(arrayOf("معمولی", "موزیک"), if (role == "music") 1 else 0) { dialog, which ->
                        role = if (which == 1) "music" else "normal"
                        text = if (role == "music") "🎧 بات موزیک" else "🤖 بات معمولی"
                        dialog.dismiss()
                    }.setNegativeButton("بستن", null).show()
            }
        }
        roleButton.text = if (role == "music") "🎧 بات موزیک" else "🤖 بات معمولی"

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(4))
        }
        listOf(nameField, tokenField, roomField, ownerField, roleButton).forEachIndexed { index, view ->
            form.addView(view, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = if (index == 0) 0 else dp(10)
            })
        }
        val dialog = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (existing == null) "افزودن بات" else "ویرایش بات")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("ذخیره", null)
            .setNegativeButton("لغو", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameField.text.toString().trim()
                val token = tokenField.text.toString().trim()
                    .ifBlank { existing?.optString("token", "").orEmpty() }
                val room = roomField.text.toString().trim()
                val owner = ownerField.text.toString().trim().removePrefix("@")
                if (name.isBlank() || token.isBlank() || room.isBlank() || owner.isBlank()) {
                    Toast.makeText(this, "نام، توکن، روم و یوزرنیم مالک را کامل کن", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val id = existing?.optString("id")?.takeIf { it.isNotBlank() }
                    ?: UUID.randomUUID().toString().replace("-", "")
                val duplicateToken = readProfiles().any {
                    it.optString("id") != id && it.optString("token") == token
                }
                if (duplicateToken || (Prefs.get(this, "mtoken").isNotBlank() && Prefs.get(this, "mtoken") == token)) {
                    Toast.makeText(this, "این توکن در پروفایل دیگری استفاده شده؛ هر بات به توکن جدا نیاز دارد.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val profile = JSONObject()
                    .put("id", id)
                    .put("name", name)
                    .put("token", token)
                    .put("room", room)
                    .put("owner", owner)
                    .put("role", role)
                    .put("enabled", existing?.optBoolean("enabled", false) ?: false)
                val profiles = readProfiles()
                val index = profiles.indexOfFirst { it.optString("id") == id }
                if (index >= 0) profiles[index] = profile else profiles.add(profile)
                saveProfilesAndSync(profiles)
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun refreshFleet() {
        val profileFile = profilesFile()
        val statusFile = File(Paths.botDir(this), "launcher_status.json")
        val stamp = profileFile.lastModified() + profileFile.length() +
            statusFile.lastModified() + statusFile.length()
        if (stamp == fleetStamp) return
        fleetStamp = stamp
        fleetBox.removeAllViews()
        val profiles = readProfiles()
        if (profiles.isEmpty()) {
            fleetBox.addView(TextView(this).apply {
                text = "هنوز بات اضافه‌ای ثبت نشده. از «افزودن بات» شروع کن."
                textSize = 12f; setTextColor(GRAY); setPadding(dp(4), dp(8), dp(4), dp(8))
            })
            return
        }
        val statuses = try {
            JSONObject(statusFile.readText()).optJSONObject("profiles") ?: JSONObject()
        } catch (_: Exception) { JSONObject() }

        profiles.forEach { profile ->
            val id = profile.optString("id")
            val name = profile.optString("name", id)
            val enabled = profile.optBoolean("enabled", false)
            val status = statuses.optJSONObject(id)?.optString("status", "stopped") ?: "stopped"
            val statusText = when (status) {
                "online" -> "آنلاین"
                "connecting" -> "در حال اتصال"
                "reconnecting" -> "اتصال مجدد"
                "error" -> "خطا در تنظیمات/اجرا"
                else -> if (enabled) "در صف اتصال" else "خاموش"
            }
            val statusColor = when (status) {
                "online" -> GREEN
                "error" -> RED
                "connecting", "reconnecting" -> GOLD
                else -> GRAY
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = box(Color.parseColor("#171717"), Color.parseColor("#5A1A3A"), 14)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            card.addView(TextView(this).apply {
                text = "🤖  $name"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(GOLD_SOFT); textDirection = View.TEXT_DIRECTION_RTL
            })
            card.addView(TextView(this).apply {
                text = "● $statusText  •  روم: ${profile.optString("room")}"
                textSize = 11f; setTextColor(statusColor); setPadding(0, dp(4), 0, dp(7))
                textDirection = View.TEXT_DIRECTION_RTL
            })
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            fun action(title: String, color: Int, onClick: () -> Unit) =
                TextView(this).apply {
                    text = title; textSize = 11f; setTextColor(color); gravity = Gravity.CENTER
                    background = box(Color.parseColor("#202020"), color, 10)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                    setOnClickListener { onClick() }
                }
            actions.addView(action(if (enabled) "توقف" else "شروع", if (enabled) RED else GREEN) {
                setProfileEnabled(id, !enabled)
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions.addView(action("لباس", GOLD) { openProfileOutfits(id, name) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions.addView(action("ویرایش", GOLD_SOFT) { openProfileEditor(profile) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions.addView(action("حذف", RED) { confirmDeleteProfile(id, name) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            card.addView(actions)
            fleetBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }

    private fun setProfileEnabled(id: String, enabled: Boolean) {
        val profiles = readProfiles()
        val profile = profiles.firstOrNull { it.optString("id") == id } ?: return
        profile.put("enabled", enabled)
        saveProfilesAndSync(profiles)
    }

    private fun stopAllProfiles() {
        val profiles = readProfiles()
        profiles.forEach { it.put("enabled", false) }
        saveProfilesAndSync(profiles)
        Toast.makeText(this, "همه‌ی بات‌های اضافی متوقف شدند", Toast.LENGTH_SHORT).show()
    }

    private fun confirmDeleteProfile(id: String, name: String) {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setMessage("بات «$name» و تنظیمات اختصاصی‌اش از لانچر حذف شود؟")
            .setPositiveButton("حذف") { _, _ ->
                val profiles = readProfiles().filterNot { it.optString("id") == id }
                saveProfilesAndSync(profiles)
                Toast.makeText(this, "پروفایل حذف شد", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("لغو", null).show()
    }

    private fun showFleetLog() {
        val text = tail(File(Paths.botDir(this), "fleet.log"), 12000)
            .ifBlank { "هنوز لاگی ثبت نشده." }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("لاگ بات‌های اضافی")
            .setMessage(text)
            .setPositiveButton("بستن", null)
            .setNeutralButton("کپی") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("fleet-log", text))
                Toast.makeText(this, "لاگ کپی شد", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun stopMainBot() {
        Prefs.setWantRunning(this, false)
        SlotLauncher.stopAll(this)
        stopService(Intent(this, ManagerService::class.java))
    }

    private fun stopAllBotSystems() {
        stopMainBot()
        val profiles = readProfiles()
        profiles.forEach { it.put("enabled", false) }
        writeProfiles(profiles)
        Prefs.setWantFleet(this, false)
        stopService(Intent(this, FleetService::class.java))
        fleetStamp = -1L
    }

    private fun confirmWipe() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setMessage("همه بات‌ها، تنظیمات، امتیازها و لاگ‌ها پاک میشن. مطمئنی؟")
            .setPositiveButton("پاک کن") { _, _ ->
                stopAllBotSystems(); Paths.botDir(this).deleteRecursively(); refresh()
            }
            .setNegativeButton("نه", null).show()
    }

    private fun tail(f: File, bytes: Int = 16000): String {
        if (!f.exists()) return ""
        return try {
            RandomAccessFile(f, "r").use { r ->
                val len = r.length()
                val start = maxOf(0L, len - bytes)
                r.seek(start)
                val buf = ByteArray((len - start).toInt())
                r.readFully(buf)
                val s = String(buf, Charsets.UTF_8)
                if (start > 0) s.substringAfter('\n', s) else s
            }
        } catch (e: Exception) { "" }
    }

    private fun logLines(n: Int) =
        tail(File(Paths.botDir(this), "manager.log")).lines().filter { it.isNotBlank() }.takeLast(n)

    private fun copyLog() {
        val text = logLines(200).joinToString("\n")
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("log", text))
        Toast.makeText(this, "لاگ کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun setsFile() = File(Paths.botDir(this), "outfit_sets.json")

    private fun readSets(): JSONObject =
        try { if (setsFile().exists()) JSONObject(setsFile().readText()) else JSONObject() }
        catch (e: Exception) { JSONObject() }

    private fun refreshOutfits() {
        val f = setsFile()
        val stamp = if (f.exists()) f.lastModified() + f.length() else 0L
        val filter = outfitFilter.text.toString().trim()
        if (stamp == outfitStamp && filter == outfitFilterValue) return
        outfitStamp = stamp
        outfitFilterValue = filter
        outfitBox.removeAllViews()
        val sets = readSets()
        val allNames = ArrayList<String>()
        val it = sets.keys()
        while (it.hasNext()) allNames.add(it.next())
        val names = allNames.filter { it.contains(filter, ignoreCase = true) }
        if (allNames.isEmpty()) {
            outfitBox.addView(TextView(this).apply {
                text = "هنوز ستی ذخیره نشده.\nتوی بازی بنویس: !copy @username"
                textSize = 12f; setTextColor(GRAY); setPadding(dp(4), dp(6), dp(4), dp(4))
            })
            return
        }
        if (names.isEmpty()) {
            outfitBox.addView(TextView(this).apply {
                text = "ستی با این نام پیدا نشد."
                textSize = 12f; setTextColor(GRAY); setPadding(dp(4), dp(8), dp(4), dp(4))
            })
            return
        }
        for (start in names.indices step 2) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            for (index in start until minOf(start + 2, names.size)) {
                val name = names[index]
                val count = sets.optJSONObject(name)?.optJSONArray("items")?.length() ?: 0
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = box(Color.parseColor("#171717"), Color.parseColor("#5A1A3A"), 14)
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                }
                card.addView(TextView(this).apply {
                    text = "👗  $name"
                    textSize = 13f
                    setTextColor(GOLD_SOFT)
                    maxLines = 2
                })
                card.addView(TextView(this).apply {
                    text = "$count آیتم"
                    textSize = 11f
                    setTextColor(GRAY)
                    setPadding(0, dp(3), 0, dp(8))
                })
                val actions = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                actions.addView(TextView(this).apply {
                    text = "بپوش"
                    textSize = 12f
                    setTextColor(Color.BLACK)
                    gravity = Gravity.CENTER
                    background = grad(GOLD, GOLD_DARK, 10)
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    setOnClickListener { wearSet(name) }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                actions.addView(TextView(this).apply {
                    text = "🗑"
                    textSize = 13f
                    setTextColor(RED)
                    gravity = Gravity.CENTER
                    setPadding(dp(10), dp(8), dp(6), dp(8))
                    setOnClickListener { confirmDeleteSet(name) }
                })
                card.addView(actions)
                row.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    setMargins(dp(3), dp(4), dp(3), dp(4))
                })
            }
            if (names.size - start == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            outfitBox.addView(row)
        }
    }

    private fun commandSections(): List<Pair<String, List<String>>> {
        val sections = ArrayList<Pair<String, List<String>>>()
        var title = "فرمان‌ها"
        var entries = ArrayList<String>()
        try {
            assets.open("bot/commands.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { raw ->
                    val line = raw.trim()
                    if (line.startsWith("▸")) {
                        entries.add(line.removePrefix("▸").trim())
                    } else if (line.contains("˚ˑ˚")) {
                        if (entries.isNotEmpty()) sections.add(title to entries)
                        title = line.split("˚ˑ˚").getOrNull(1)?.trim().orEmpty().ifBlank { title }
                        entries = ArrayList()
                    }
                }
            }
        } catch (e: Exception) {
            sections.add("راهنما" to listOf("فهرست فرمان‌ها خوانده نشد: ${e.message ?: "خطای فایل"}"))
        }
        if (entries.isNotEmpty()) sections.add(title to entries)
        return sections
    }

    private fun renderCommandCatalog(query: String) {
        commandList.removeAllViews()
        val search = query.trim()
        val visibleSections = commandSections().mapNotNull { (title, entries) ->
            val visible = if (search.isBlank() || title.contains(search, ignoreCase = true)) {
                entries
            } else {
                entries.filter { it.contains(search, ignoreCase = true) }
            }
            if (visible.isEmpty()) null else title to visible
        }
        if (visibleSections.isEmpty()) {
            commandList.addView(TextView(this).apply {
                text = "فرمانی با این عبارت پیدا نشد."
                textSize = 12f
                setTextColor(GRAY)
                setPadding(dp(4), dp(10), dp(4), dp(6))
            })
            return
        }
        for ((title, entries) in visibleSections) {
            val section = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = box(Color.parseColor("#151515"), Color.parseColor("#263B5C"), 14)
                setPadding(dp(10), dp(7), dp(10), dp(9))
            }
            section.addView(TextView(this).apply {
                text = title
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(GOLD)
                setPadding(dp(2), dp(3), dp(2), dp(6))
            })
            for (entry in entries) {
                val parts = entry.split("→", limit = 2)
                val usage = parts[0].trim()
                val description = parts.getOrNull(1)?.trim().orEmpty()
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(2), dp(6), dp(2), dp(6))
                }
                val textColumn = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                }
                textColumn.addView(TextView(this).apply {
                    text = usage
                    textSize = 12f
                    setTextColor(Color.parseColor("#8BB8FF"))
                    textDirection = View.TEXT_DIRECTION_RTL
                })
                if (description.isNotBlank()) {
                    textColumn.addView(TextView(this).apply {
                        text = description
                        textSize = 11f
                        setTextColor(GRAY)
                        textDirection = View.TEXT_DIRECTION_RTL
                        setPadding(0, dp(2), 0, 0)
                    })
                }
                item.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
                item.addView(TextView(this).apply {
                    text = "⧉"
                    textSize = 16f
                    setTextColor(GOLD_SOFT)
                    gravity = Gravity.CENTER
                    setPadding(dp(10), dp(4), dp(4), dp(4))
                    contentDescription = "کپی فرمان"
                    setOnClickListener { copyCommand(usage) }
                })
                section.addView(item)
            }
            commandList.addView(section, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(8)
            })
        }
    }

    private fun copyCommand(command: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("command", command))
        Toast.makeText(this, "فرمان کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun wearSet(name: String, profileId: String? = null) {
        try {
            val botDir = Paths.botDir(this).apply { mkdirs() }
            val pendingName = if (profileId.isNullOrBlank()) {
                "pending_outfit.json"
            } else {
                "pending_outfit_${profileId}.json"
            }
            File(botDir, pendingName)
                .writeText(JSONObject().put("set", name).toString())
            Toast.makeText(this, "درخواست پوشیدن «$name» ثبت شد؛ اگر بات آنلاین باشد در بازی اعمال می‌شود.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا: $e", Toast.LENGTH_LONG).show()
        }
    }

    private fun openProfileOutfits(profileId: String, botName: String) {
        val setsFile = File(Paths.botDir(this), "outfit_sets_${profileId}.json")
        val sets = try {
            if (setsFile.exists()) JSONObject(setsFile.readText()) else JSONObject()
        } catch (_: Exception) { JSONObject() }
        val names = ArrayList<String>()
        val keys = sets.keys()
        while (keys.hasNext()) names.add(keys.next())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(4))
        }
        if (names.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "برای این بات هنوز ستی ذخیره نشده.\nداخل بازی بزن: !copy @username"
                textSize = 13f; setTextColor(GRAY); setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            names.forEach { setName ->
                val count = sets.optJSONObject(setName)?.optJSONArray("items")?.length() ?: 0
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                row.addView(TextView(this).apply {
                    text = "$setName  ($count)"; textSize = 13f; setTextColor(GOLD_SOFT)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(TextView(this).apply {
                    text = "بپوش"; textSize = 11f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
                    background = grad(GOLD, GOLD_DARK, 9); setPadding(dp(10), dp(7), dp(10), dp(7))
                    setOnClickListener { wearSet(setName, profileId) }
                })
                row.addView(TextView(this).apply {
                    text = "حذف"; textSize = 11f; setTextColor(RED); gravity = Gravity.CENTER
                    setPadding(dp(8), dp(7), dp(6), dp(7))
                    setOnClickListener { confirmDeleteSet(setName, profileId) }
                })
                content.addView(row)
            }
        }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("ست‌های لباس — $botName")
            .setView(ScrollView(this).apply { addView(content) })
            .setPositiveButton("بستن", null)
            .show()
    }

    private fun confirmDeleteSet(name: String, profileId: String? = null) {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setMessage("ست «$name» پاک بشه؟")
            .setPositiveButton("پاک کن") { _, _ ->
                val target = if (profileId.isNullOrBlank()) {
                    val sets = readSets()
                    sets.remove(name)
                    try { setsFile().writeText(sets.toString()) } catch (_: Exception) {}
                    null
                } else {
                    val file = File(Paths.botDir(this), "outfit_sets_${profileId}.json")
                    val sets = try { if (file.exists()) JSONObject(file.readText()) else JSONObject() }
                        catch (_: Exception) { JSONObject() }
                    sets.remove(name)
                    try { file.writeText(sets.toString()) } catch (_: Exception) {}
                    profileId
                }
                if (target == null) {
                    outfitStamp = -1L
                    refreshOutfits()
                } else {
                    Toast.makeText(this, "ست حذف شد؛ دوباره بخش لباس بات را باز کن.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("نه", null).show()
    }

    private fun refresh() {
        refreshOutfits()
        refreshFleet()
        val running = Prefs.wantRunning(this)
        val lines = logLines(30)
        val tailText = lines.joinToString("\n")

        // status pill
        val (txt, color) = if (!running) "آفلاین" to GRAY else {
            val on = tailText.lastIndexOf("آنلاین شد")
            val conn = tailText.lastIndexOf("در حال اتصال")
            val err = tailText.lastIndexOf("خطای واقعی")
            val last = maxOf(on, conn, err)
            when {
                last < 0 -> "در حال راه‌اندازی..." to GOLD
                last == on -> "آنلاین توی روم" to GREEN
                last == err -> "قطع شد، اتصال مجدد..." to RED
                else -> "در حال اتصال..." to GOLD
            }
        }
        pill.text = "●  $txt"; pill.setTextColor(color)
        pill.background = box(Color.parseColor("#0F0F0F"), color, 20)

        // main button
        if (running) {
            mainBtn.text = "■  توقف بات اصلی"; mainBtn.setTextColor(Color.WHITE)
            mainBtn.background = grad(Color.parseColor("#B3261E"), Color.parseColor("#E05555"))
        } else {
            mainBtn.text = "استارت  ▶"; mainBtn.setTextColor(Color.BLACK)
            mainBtn.background = grad(GOLD, GOLD_DARK)
        }

        val ign = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        batteryLink.text = if (ign) "🔋 محدودیت باتری برداشته شده ✔" else "🔋 غیرفعال کردن محدودیت باتری (برای روشن موندن)"

        // log text with colors
        val sb = SpannableStringBuilder()
        if (lines.isEmpty()) sb.append("> waiting...")
        for (l in lines) {
            val start = sb.length
            sb.append(l).append('\n')
            val c = when {
                l.contains("ERROR") || l.contains("Error") || l.contains("Traceback") || l.contains("❌") || l.contains("خطا") -> RED
                l.contains("✅") || l.contains("آنلاین") || l.contains("👑") -> GREEN
                else -> GOLD_SOFT
            }
            sb.setSpan(ForegroundColorSpan(c), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (logView.text.toString() != sb.toString()) logView.text = sb
    }

    private fun ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
