# regular package (namespace-safe for Chaquopy)
