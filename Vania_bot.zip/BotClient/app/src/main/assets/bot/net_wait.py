"""Wait until the internet is reachable (polls every second)."""
import asyncio
import logging
import socket

log = logging.getLogger("net_wait")
_last_err = None


def _can_resolve() -> bool:
    global _last_err
    try:
        socket.getaddrinfo("highrise.game", 443, type=socket.SOCK_STREAM)
        return True
    except OSError as e:
        _last_err = e
        return False


async def wait_for_network(poll: float = 1.0) -> None:
    loop = asyncio.get_running_loop()
    tries = 0
    while not await loop.run_in_executor(None, _can_resolve):
        tries += 1
        if tries == 1 or tries % 10 == 0:
            log.warning("🌐 اینترنت/DNS در دسترس نیست (%s)، منتظر می‌مونم...", _last_err)
        await asyncio.sleep(poll)
    if tries:
        log.info("🌐 اینترنت وصل شد")
