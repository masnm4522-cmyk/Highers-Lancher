"""
دو سیستم به سبک بات تنتا:

۱) سیستم ادمین (مالک > ادمین ویژه > ادمین)
     !admin add @user            → افزودن ادمین (فقط مالک)
     !admin remove @user         → حذف ادمین (فقط مالک)
     !admin vip add @user        → افزودن ادمین ویژه (فقط مالک)
     !admin vip remove @user     → حذف ادمین ویژه (فقط مالک)
     !admin list                 → لیست ادمین‌ها
   دستور !spam فقط برای مالک و ادمین ویژه‌ست.
   لیست ادمین‌ها با config["admin_usernames"] هماهنگ می‌شه تا بقیه‌ی دستورهای بات هم درست کار کنن.

۲) سیستم لباس (کپی لباس + ست‌های ذخیره‌شده توی لانچر)
     !copy @user [اسم]           → لباس اون کاربر رو کپی می‌کنه، می‌پوشه و به‌عنوان ست ذخیره می‌کنه
     !outfit save <اسم>          → لباس فعلی بات رو به‌عنوان ست ذخیره می‌کنه
     !outfit list                → لیست ست‌ها
     !outfit wear <اسم>          → پوشیدن ست
     !outfit del <اسم>           → حذف ست
   ست‌ها توی فایل outfit_sets.json ذخیره می‌شن و لانچر (Vania) اون‌ها رو نشون می‌ده.
   لانچر با نوشتن pending_outfit.json می‌تونه به بات بگه یک ست رو بپوشه.
"""
import os
import logging
from datetime import datetime
from asyncio import create_task, sleep

from highrise import User
from highrise.models import Item, Error
from persistent_store import load_json, save_json

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ADMIN_FILE = os.path.join(BASE_DIR, "tental_admin.json")
OUTFIT_FILE = os.path.join(BASE_DIR, "outfit_sets.json")
PENDING_FILE = os.path.join(BASE_DIR, "pending_outfit.json")

# اجزای پایه‌ی رایگان که بات همیشه می‌تونه بپوشه (برای حالت جایگزین وقتی لباسِ پولی رو نداره)
_BASE_PREFIXES = ("body-", "eye-", "eyebrow-", "mouth-", "nose-", "hair_front-", "hair_back-")

_ADMIN_HELP = (
    "👑 دستورات مدیریت ادمین‌ها:\n"
    "• !admin add @user - افزودن ادمین\n"
    "• !admin remove @user - حذف ادمین\n"
    "• !admin vip add @user - افزودن ادمین ویژه\n"
    "• !admin vip remove @user - حذف ادمین ویژه\n"
    "• !admin list - نمایش لیست ادمین‌ها"
)

_OUTFIT_HELP = (
    "👗 سیستم لباس:\n"
    "• !copy @user [اسم] - کپی و پوشیدن لباس کاربر (و ذخیره به‌عنوان ست)\n"
    "• !outfit save <اسم> - ذخیره‌ی لباس فعلی بات\n"
    "• !outfit list - لیست ست‌ها\n"
    "• !outfit wear <اسم> - پوشیدن ست\n"
    "• !outfit del <اسم> - حذف ست"
)


def _item_to_dict(item) -> dict:
    return {
        "type": getattr(item, "type", "clothing"),
        "amount": int(getattr(item, "amount", 1) or 1),
        "id": item.id,
        "account_bound": bool(getattr(item, "account_bound", False)),
        "active_palette": getattr(item, "active_palette", None),
    }


def _dict_to_item(d: dict) -> Item:
    return Item(
        type=d.get("type", "clothing"),
        amount=int(d.get("amount", 1) or 1),
        id=d["id"],
        account_bound=bool(d.get("account_bound", False)),
        active_palette=d.get("active_palette"),
    )


class TentalSystemsMixin:

    def _tental_file(self, stem: str, legacy_name: str) -> str:
        bot_name = str(getattr(self, "bot_name", "Vania")).strip()
        if bot_name in ("", "Vania", "default"):
            return os.path.join(BASE_DIR, legacy_name)
        safe_name = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in bot_name)
        return os.path.join(BASE_DIR, f"{stem}_{safe_name}.json")

    def _tental_admin_file(self) -> str:
        return self._tental_file("tental_admin", "tental_admin.json")

    def _outfit_file(self) -> str:
        return self._tental_file("outfit_sets", "outfit_sets.json")

    def _pending_outfit_file(self) -> str:
        return self._tental_file("pending_outfit", "pending_outfit.json")

    # ───────────────────────── راه‌اندازی ─────────────────────────

    def _tental_init(self):
        owner = str(getattr(self, "owner_username", "")).strip().lower()
        self._t_owners = {owner} if owner else set()

        admin_file = self._tental_admin_file()
        data = load_json(admin_file, None)
        if not isinstance(data, dict):
            # بار اول: ادمین‌های قبلی رو نگه می‌داریم تا کسی دسترسیش رو از دست نده
            old = [str(u).lower() for u in self.config.get("admin_usernames", []) if u]
            data = {"admins": [u for u in old if u not in self._t_owners], "vip_admins": []}
            save_json(admin_file, data)
        self._t_admins = [str(u).lower() for u in data.get("admins", [])]
        self._t_vips = [str(u).lower() for u in data.get("vip_admins", [])]
        self._tadmin_sync()
        self._outfit_poll_task = None

    def _tental_on_start(self):
        logger.info("🟢 بات آنلاین شد و سیستم لباس فعال شد")
        if self._outfit_poll_task is None or self._outfit_poll_task.done():
            self._outfit_poll_task = create_task(self._outfit_poll())

    # ───────────────────────── سیستم ادمین ─────────────────────────

    def _tadmin_save(self):
        save_json(self._tental_admin_file(), {"admins": self._t_admins, "vip_admins": self._t_vips})
        self._tadmin_sync()

    def _tadmin_sync(self):
        combined = []
        for u in list(self._t_owners) + self._t_vips + self._t_admins:
            if u and u not in combined:
                combined.append(u)
        self.config["admin_usernames"] = combined
        try:
            self.save_config()
        except Exception:
            pass

    def _t_is_owner(self, user: User) -> bool:
        return user.username.lower() in self._t_owners

    def _t_is_vip(self, user: User) -> bool:
        name = user.username.lower()
        return name in self._t_owners or name in self._t_vips

    def _t_is_admin(self, user: User) -> bool:
        name = user.username.lower()
        return name in self._t_owners or name in self._t_vips or name in self._t_admins

    @staticmethod
    def _t_clean(name: str) -> str:
        return name.strip().lstrip("@").lower()

    async def _tadmin_cmd(self, user: User, msg: str):
        say = self.highrise.chat
        args = msg.split()[1:]
        sub = args[0].lower() if args else ""

        if sub == "list":
            if not self._t_is_admin(user):
                await say("❌ فقط ادمین‌ها می‌تونن لیست رو ببینن!")
                return
            owners = ", ".join(f"@{u}" for u in sorted(self._t_owners)) or "—"
            vips = ", ".join(f"@{u}" for u in self._t_vips) or "—"
            admins = ", ".join(f"@{u}" for u in self._t_admins) or "—"
            await say(f"👑 مالک: {owners}\n⭐ ادمین ویژه: {vips}\n🛡 ادمین: {admins}")
            return

        if not self._t_is_owner(user):
            await say("❌ فقط مالک می‌تونه ادمین‌ها رو مدیریت کنه!")
            return

        if sub in ("add", "remove") and len(args) >= 2:
            target = self._t_clean(args[1])
            if not target:
                await say(_ADMIN_HELP)
                return
            if sub == "add":
                if target in self._t_owners or target in self._t_admins:
                    await say(f"ℹ️ @{target} از قبل ادمینه.")
                    return
                self._t_vips = [u for u in self._t_vips if u != target]
                self._t_admins.append(target)
                self._tadmin_save()
                await say(f"✅ @{target} ادمین شد.")
            else:
                if target in self._t_owners:
                    await say("❌ مالک رو نمی‌شه حذف کرد!")
                    return
                if target not in self._t_admins:
                    await say(f"ℹ️ @{target} ادمین نیست.")
                    return
                self._t_admins = [u for u in self._t_admins if u != target]
                self._tadmin_save()
                await say(f"✅ @{target} از ادمین‌ها حذف شد.")
            return

        if sub == "vip" and len(args) >= 3 and args[1].lower() in ("add", "remove"):
            target = self._t_clean(args[2])
            if not target:
                await say(_ADMIN_HELP)
                return
            if args[1].lower() == "add":
                if target in self._t_owners or target in self._t_vips:
                    await say(f"ℹ️ @{target} از قبل ادمین ویژه‌ست.")
                    return
                self._t_admins = [u for u in self._t_admins if u != target]
                self._t_vips.append(target)
                self._tadmin_save()
                await say(f"✅ @{target} ادمین ویژه شد. ⭐")
            else:
                if target not in self._t_vips:
                    await say(f"ℹ️ @{target} ادمین ویژه نیست.")
                    return
                self._t_vips = [u for u in self._t_vips if u != target]
                self._tadmin_save()
                await say(f"✅ @{target} از ادمین ویژه‌ها حذف شد.")
            return

        await say(_ADMIN_HELP)

    # ───────────────────────── سیستم لباس ─────────────────────────

    def _outfit_sets(self) -> dict:
        data = load_json(self._outfit_file(), {})
        return data if isinstance(data, dict) else {}

    def _outfit_save_sets(self, sets: dict):
        save_json(self._outfit_file(), sets)

    @staticmethod
    def _outfit_key(name: str) -> str:
        return name.strip().lower()

    async def _t_find_room_user(self, username: str):
        resp = await self.highrise.get_room_users()
        for u, _pos in getattr(resp, "content", []):
            if u.username.lower() == username:
                return u
        return None

    async def _t_fetch_outfit(self, user_id: str):
        resp = await self.highrise.get_user_outfit(user_id)
        if isinstance(resp, Error) or not hasattr(resp, "outfit"):
            return None
        return list(resp.outfit)

    async def _t_apply_items(self, items: list):
        """لباس رو می‌پوشه. اگه بات بعضی آیتم‌ها رو نداشت، فقط اونایی که داره (و اجزای پایه) رو می‌پوشه.
        خروجی: (تعداد پوشیده‌شده، تعداد کل)"""
        total = len(items)
        if not total:
            return 0, 0
        result = await self.highrise.set_outfit(items)
        if not isinstance(result, Error):
            return total, total
        inv = await self.highrise.get_inventory()
        owned = {i.id for i in getattr(inv, "items", [])} if not isinstance(inv, Error) else set()
        keep = [i for i in items if i.id in owned or i.id.startswith(_BASE_PREFIXES)]
        if not keep:
            return 0, total
        result = await self.highrise.set_outfit(keep)
        if isinstance(result, Error):
            return 0, total
        return len(keep), total

    async def _outfit_wear_set(self, key: str):
        sets = self._outfit_sets()
        entry = sets.get(key)
        if not entry:
            return None
        items = [_dict_to_item(d) for d in entry.get("items", []) if d.get("id")]
        return await self._t_apply_items(items)

    async def _outfit_cmd(self, user: User, msg: str):
        say = self.highrise.chat
        parts = msg.split()
        cmd = parts[0].lower()

        if not self._t_is_admin(user):
            await say("❌ فقط ادمین‌ها می‌تونن از سیستم لباس استفاده کنن!")
            return

        # !copy @user [اسم]
        if cmd in ("!copy", "!copyoutfit"):
            if len(parts) < 2:
                await say("❌ فرمت: !copy @user [اسم ست]")
                return
            target_name = self._t_clean(parts[1])
            target = await self._t_find_room_user(target_name)
            if target is None:
                await say(f"❌ @{target_name} توی روم پیدا نشد!")
                return
            items = await self._t_fetch_outfit(target.id)
            if not items:
                await say("❌ نشد لباسش رو بگیرم!")
                return
            set_name = self._outfit_key(" ".join(parts[2:])) if len(parts) > 2 else target.username.lower()
            sets = self._outfit_sets()
            sets[set_name] = {
                "items": [_item_to_dict(i) for i in items],
                "source": target.username,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
            }
            self._outfit_save_sets(sets)
            worn, total = await self._t_apply_items(items)
            if worn == total:
                await say(f"👗 لباس @{target.username} پوشیده شد و به‌عنوان ست «{set_name}» ذخیره شد ✅")
            elif worn:
                await say(f"👗 {worn} از {total} آیتم پوشیده شد (بقیه رو بات نداره). ست «{set_name}» ذخیره شد.")
            else:
                await say(f"⚠️ ست «{set_name}» ذخیره شد ولی بات نتونست بپوشدش (آیتم‌ها رو نداره).")
            return

        # !outfit ...
        sub = parts[1].lower() if len(parts) > 1 else ""
        name = self._outfit_key(" ".join(parts[2:])) if len(parts) > 2 else ""

        if sub == "list":
            sets = self._outfit_sets()
            if not sets:
                await say("📭 هنوز هیچ ستی ذخیره نشده. با !copy @user یکی بساز.")
                return
            lines = [f"{i}. {n} ({len(v.get('items', []))} آیتم)" for i, (n, v) in enumerate(sets.items(), 1)]
            await say("👗 ست‌های لباس:\n" + "\n".join(lines[:15]))
            return

        if sub == "save" and name:
            if not self.user_id:
                await say("❌ شناسه‌ی بات هنوز آماده نیست!")
                return
            items = await self._t_fetch_outfit(self.user_id)
            if not items:
                await say("❌ نشد لباس بات رو بگیرم!")
                return
            sets = self._outfit_sets()
            sets[name] = {
                "items": [_item_to_dict(i) for i in items],
                "source": "bot",
                "saved_at": datetime.now().isoformat(timespec="seconds"),
            }
            self._outfit_save_sets(sets)
            await say(f"✅ لباس فعلی بات به‌عنوان ست «{name}» ذخیره شد.")
            return

        if sub == "wear" and name:
            res = await self._outfit_wear_set(name)
            if res is None:
                await say(f"❌ ستی به اسم «{name}» پیدا نشد!")
            else:
                worn, total = res
                if worn == total and total:
                    await say(f"👗 ست «{name}» پوشیده شد ✅")
                elif worn:
                    await say(f"👗 {worn} از {total} آیتم ست «{name}» پوشیده شد.")
                else:
                    await say(f"⚠️ بات نتونست ست «{name}» رو بپوشه.")
            return

        if sub in ("del", "delete", "remove") and name:
            sets = self._outfit_sets()
            if name not in sets:
                await say(f"❌ ستی به اسم «{name}» پیدا نشد!")
                return
            sets.pop(name)
            self._outfit_save_sets(sets)
            await say(f"🗑 ست «{name}» حذف شد.")
            return

        await say(_OUTFIT_HELP)

    async def _outfit_poll(self):
        """منتظر درخواست لانچر مخصوص همین بات می‌مونه."""
        while True:
            try:
                await sleep(0.75)
                pending_file = self._pending_outfit_file()
                if not os.path.exists(pending_file):
                    continue
                data = load_json(pending_file, None)
                try:
                    os.remove(pending_file)
                except OSError:
                    pass
                if not isinstance(data, dict):
                    continue
                if data.get("set"):
                    res = await self._outfit_wear_set(self._outfit_key(str(data["set"])))
                    logger.info(f"👗 ست «{data['set']}» از لانچر اعمال شد: {res}")
                elif isinstance(data.get("outfit"), list):
                    items = [_dict_to_item(d) for d in data["outfit"] if isinstance(d, dict) and d.get("id")]
                    res = await self._t_apply_items(items)
                    logger.info(f"👗 لباس از لانچر اعمال شد: {res}")
            except Exception as exc:
                logger.error(f"خطا در سیستم لباس: {exc}")

    # ───────────────────────── ورودی چت ─────────────────────────

    async def _tental_on_chat(self, user: User, message: str) -> bool:
        """اگه پیام یکی از دستورهای این فایل بود پردازشش می‌کنه و True برمی‌گردونه."""
        msg = message.strip()
        if not msg.startswith("!"):
            return False
        cmd = msg.split()[0].lower()

        if cmd == "!admin":
            await self._tadmin_cmd(user, msg)
            return True

        if cmd in ("!addadmin", "!removeadmin", "!listadd"):
            await self.highrise.chat("ℹ️ سیستم ادمین عوض شده. از !admin add @user یا !admin remove @user یا !admin list استفاده کن.")
            return True

        if cmd == "!spam" and not self._t_is_vip(user):
            await self.highrise.chat("❌ فقط مالک یا ادمین ویژه!")
            return True

        if cmd in ("!copy", "!copyoutfit", "!outfit"):
            await self._outfit_cmd(user, msg)
            return True

        return False
