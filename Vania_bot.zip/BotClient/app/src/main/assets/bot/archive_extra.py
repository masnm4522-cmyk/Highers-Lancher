"""
سیستم خاطرات و آرشیو روم.

خودکار رکورد جمعیت هم‌زمان روم رو دنبال می‌کنه و هر بار که رکورد
جدید شکسته بشه، توی چت اعلام می‌کنه و توی یه آرشیو (فایل + حافظه)
ذخیره‌ش می‌کنه. با !memories می‌شه آخرین خاطرات رو دید.

دستور:
  !memories → نمایش آخرین خاطرات/رکوردهای ثبت‌شده‌ی روم
"""

import time
from collections import deque

from highrise import User


class ArchiveExtraMixin:

    def _init_archive_state(self):
        if not hasattr(self, "_archive_events"):
            saved = self.ext_config.get("archive_events", [])
            self._archive_events = deque(saved, maxlen=50)
        if not hasattr(self, "_room_peak"):
            self._room_peak = self.ext_config.get("room_peak", 0)

    def _record_memory(self, text: str):
        self._init_archive_state()
        stamp = time.strftime("%Y-%m-%d %H:%M")
        entry = f"[{stamp}] {text}"
        self._archive_events.append(entry)
        self.ext_config["archive_events"] = list(self._archive_events)
        self._save_ext_config()

    async def _check_room_record(self):
        """هر بار یکی وارد میشه صداش می‌زنیم؛ اگه رکورد جدید بود اعلام می‌کنه."""
        self._init_archive_state()
        current = len(self.active_users)
        if current > self._room_peak:
            self._room_peak = current
            self.ext_config["room_peak"] = current
            self._save_ext_config()
            self._record_memory(f"🎉 رکورد جدید جمعیت هم‌زمان روم: {current} نفر!")
            try:
                await self.highrise.chat(
                    f"🎉 رکورد جدید شکسته شد! الان {current} نفر همزمان تو روم هستن! 🔥"
                )
            except Exception:
                pass

    async def _cmd_memories(self, user: User, message: str):
        self._init_archive_state()
        if not self._archive_events:
            await self.highrise.chat("📭 هنوز هیچ خاطره‌ای ثبت نشده.")
            return
        lines = list(self._archive_events)[-8:]
        await self.highrise.chat("📸 آخرین خاطرات روم:\n" + "\n".join(lines))
