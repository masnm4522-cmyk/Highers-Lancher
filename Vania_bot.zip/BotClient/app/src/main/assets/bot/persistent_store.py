"""Small, dependency-free, crash-safe JSON storage for the Termux bot.

All writes happen in the same directory as the destination file and finish
with os.replace(), so a phone shutdown cannot leave a half-written JSON file.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from typing import Any

logger = logging.getLogger(__name__)


def load_json(path: str, default: Any) -> Any:
    """Load JSON and return a fresh default when the file is missing/invalid."""
    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        return default
    except (OSError, json.JSONDecodeError) as exc:
        logger.error("Could not load persistent file %s: %s", path, exc)
        return default


def save_json(path: str, value: Any) -> None:
    """Atomically save JSON and flush it to disk before replacing the old file."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    file_descriptor, temporary_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(path)}.",
        suffix=".tmp",
        dir=directory,
    )
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8") as file:
            json.dump(value, file, indent=4, ensure_ascii=False)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except Exception:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        raise