"""Dynamic in-process runner for the launcher's saved bot profiles."""
import asyncio
import json
import logging
import os
import re
import time

logger = logging.getLogger(__name__)
_PROFILE_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


def _read_profiles(path):
    try:
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _write_json(path, data):
    temp_path = path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp_path, path)


async def run_fleet(bot_dir):
    """Watch launcher_bots.json and run enabled profiles without a fixed slot count."""
    profiles_path = os.path.join(bot_dir, "launcher_bots.json")
    status_path = os.path.join(bot_dir, "launcher_status.json")
    running = {}
    statuses = {}
    from extended_serve2 import run_bot_profile

    def set_status(profile_id, name, status, detail=""):
        statuses[profile_id] = {
            "name": name,
            "status": status,
            "detail": str(detail)[:240],
            "updated_at": int(time.time()),
        }
        try:
            _write_json(status_path, {"profiles": statuses})
        except OSError as exc:
            logger.warning("Could not write fleet status: %s", exc)

    async def run_one(profile):
        profile_id = profile["id"]
        name = profile["name"]
        set_status(profile_id, name, "connecting")
        try:
            await run_bot_profile(
                api_token=profile["token"],
                room_id=profile["room"],
                bot_name=profile_id,
                owner_username=profile.get("owner", ""),
                bot_role=profile.get("role", "normal"),
                display_name=name,
                status_callback=lambda state: set_status(profile_id, name, state),
            )
            set_status(profile_id, name, "stopped")
        except asyncio.CancelledError:
            set_status(profile_id, name, "stopped")
            raise
        except Exception as exc:
            logger.exception("Bot profile %s stopped unexpectedly", profile_id)
            set_status(profile_id, name, "error", type(exc).__name__)

    async def cancel_profile(profile_id, entry):
        entry["task"].cancel()
        try:
            await entry["task"]
        except (asyncio.CancelledError, Exception):
            pass
        profile = entry["profile"]
        set_status(profile_id, profile.get("name", profile_id), "stopped")

    while True:
        desired = {}
        for profile in _read_profiles(profiles_path):
            if not isinstance(profile, dict) or not profile.get("enabled"):
                continue
            profile_id = str(profile.get("id", "")).strip()
            name = str(profile.get("name", "")).strip()
            token = str(profile.get("token", "")).strip()
            room = str(profile.get("room", "")).strip()
            if not _PROFILE_ID.fullmatch(profile_id) or not name or not token or not room:
                if profile_id and _PROFILE_ID.fullmatch(profile_id):
                    set_status(profile_id, name or profile_id, "error", "تنظیمات ناقص است")
                continue
            desired[profile_id] = {
                "id": profile_id,
                "name": name,
                "token": token,
                "room": room,
                "owner": str(profile.get("owner", "")).strip(),
                "role": str(profile.get("role", "normal")).strip().lower() or "normal",
                "enabled": True,
            }

        for profile_id, entry in list(running.items()):
            profile = desired.get(profile_id)
            if profile is None or profile != entry["profile"] or entry["task"].done():
                await cancel_profile(profile_id, entry)
                running.pop(profile_id, None)

        for profile_id, profile in desired.items():
            if profile_id not in running:
                task = asyncio.create_task(run_one(profile), name=f"bot-{profile_id}")
                running[profile_id] = {"profile": profile, "task": task}

        await asyncio.sleep(2)
