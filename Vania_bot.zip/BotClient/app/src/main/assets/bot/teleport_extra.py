"""
سیستم اضافه‌ی تلپورت (!tele و !summ)
این فایل جدا از serve2.py و extended_serve2.py هست تا این دو دستور
مستقل بمونن و راحت‌تر بشه نگه‌داری‌شون کرد.

دستورها (فقط ادمین):
  !tele @یوزرنیم            -> ادمین میره پیش اون کاربر
  !tele @یوزرنیم اسم_طبقه   -> اون کاربر میره به طبقه/مکان مشخص شده
                               (طبقه‌های عادی و VIP هر دو کار می‌کنن)
  !summ @یوزرنیم            -> اون کاربر میاد پیش ادمین (احضار)
"""

from highrise import User, Position
from asyncio import sleep


class TeleportExtraMixin:
    async def _cmd_tele_extra(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return

        parts = message.strip().split()
        if len(parts) < 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !tele @یوزرنیم  یا  !tele @یوزرنیم اسم_طبقه")
            return

        target_username = parts[1][1:].lower()
        target_user = self.active_users.get(target_username)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target_username} توی روم پیدا نشد.")
            return

        try:
            if len(parts) == 2:
                target_pos = self.user_positions.get(target_username)
                if not target_pos:
                    await self.highrise.chat("❌ موقعیت این کاربر در دسترس نیست.")
                    return
                dest = Position(x=target_pos.x, y=target_pos.y, z=target_pos.z)
                await self.highrise.teleport(user_id=user.id, dest=dest)
                await self.highrise.chat(f"✅ @{user.username} پیش @{target_user.username} تلپورت شد.")
            else:
                floor_name = parts[2].lower()
                floors = self.ext_config.get("floors", {}) if hasattr(self, "ext_config") else {}
                if floor_name in floors:
                    f = floors[floor_name]
                    dest = Position(x=f["x"], y=f["y"], z=f["z"])
                elif floor_name in self.config.get("teleport_locations", {}):
                    f = self.config["teleport_locations"][floor_name]
                    dest = Position(x=f["x"], y=f["y"], z=f["z"])
                else:
                    await self.highrise.chat(f"❌ طبقه یا مکان '{floor_name}' وجود نداره.")
                    return
                await self.highrise.teleport(user_id=target_user.id, dest=dest)
                await self.highrise.chat(f"✅ @{target_user.username} به '{floor_name}' تلپورت شد.")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در تلپورت: {e}")

    async def _cmd_summ(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return

        parts = message.strip().split()

        # !summ all  یا  !summ play all -> همه رو یه‌جا جمع کن پیش ادمین
        lowered = [p.lower() for p in parts[1:]]
        if lowered and "all" in lowered:
            admin_pos = self.user_positions.get(user.username.lower())
            if not admin_pos:
                await self.highrise.chat("❌ موقعیت شما در دسترس نیست.")
                return
            dest = Position(x=admin_pos.x, y=admin_pos.y, z=admin_pos.z)
            count = 0
            for username, target_user in list(self.active_users.items()):
                if target_user.id == getattr(self, "user_id", None):
                    continue
                try:
                    await self.highrise.teleport(user_id=target_user.id, dest=dest)
                    count += 1
                    await sleep(0.3)
                except Exception:
                    continue
            await self.highrise.chat(f"✅ {count} نفر پیش @{user.username} جمع شدن.")
            return

        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !summ @یوزرنیم  یا  !summ all")
            return

        target_username = parts[1][1:].lower()
        target_user = self.active_users.get(target_username)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target_username} توی روم پیدا نشد.")
            return

        admin_pos = self.user_positions.get(user.username.lower())
        if not admin_pos:
            await self.highrise.chat("❌ موقعیت شما در دسترس نیست.")
            return

        try:
            dest = Position(x=admin_pos.x, y=admin_pos.y, z=admin_pos.z)
            await self.highrise.teleport(user_id=target_user.id, dest=dest)
            await self.highrise.chat(f"✅ @{target_user.username} پیش @{user.username} احضار شد.")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در احضار: {e}")
